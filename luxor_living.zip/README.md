# LUXORliving KNX Integration

[![hacs_badge](https://img.shields.io/badge/HACS-Custom-orange.svg)](https://github.com/custom-components/hacs)
[![GitHub Release](https://img.shields.io/github/release/phismith91/luxorliving.svg)](https://github.com/phismith91/luxorliving/releases)
[![License](https://img.shields.io/github/license/phismith91/luxorliving.svg)](LICENSE)

Integrate Theben LUXORliving (BAOS 777) KNX gateways with automatic entity discovery from LXP project files.

## Features

- **Automatic entity discovery** – Upload LXP file, entities are created automatically
- **KNX/IP native** – Tunneling and routing modes supported
- **Real-time updates** – Instant state changes from physical switches
- **Config Flow UI** – Setup in <2 minutes via HA interface
- **HACS compatible** – One-click installation

**Working platforms:** Light, Switch, Binary Sensor, Sensor (NEW!)  
**In development:** Climate, Cover

---

## Quick Start

### 1. Prerequisites

- Theben LUXORliving IP1 Gateway (BAOS 777)
- LXP project file (export from Theben LUXORPlug software)
- Home Assistant ≥ 2024.12.0

### 2. Installation

**HACS (recommended):**
1. Open HACS → Integrations → ⋮ (menu) → Custom repositories
2. Add `https://github.com/phismith91/luxorliving` as Integration
3. Click Download → Restart Home Assistant

**Manual:**
1. Copy `custom_components/luxor_living` to your HA config directory
2. Restart Home Assistant

### 3. Configuration

1. **Settings** → **Devices & Services** → **Add Integration** → **LUXORliving**
2. Upload LXP file (or enter path like `/config/luxor/project.lxp`)
3. Enter gateway IP (port 3671 is used automatically)
4. Select connection type: **Tunneling** (recommended) or Routing
5. Click Submit

Entities are created automatically based on your LXP project.

---

## Usage Examples

### Automation with Physical Switches

Physical KNX switches trigger HA automations instantly:

```yaml
automation:
  - alias: "Living room motion detected"
    trigger:
      - platform: state
        entity_id: binary_sensor.bewegungsmelder_wohnzimmer
        to: "on"
    action:
      - service: light.turn_on
        target:
          entity_id: light.deckenleuchte_wohnzimmer
```

### Lovelace Card

```yaml
type: entities
title: LUXORliving
entities:
  - entity: light.deckenleuchte_wohnzimmer
  - entity: switch.steckdose_kueche
  - entity: binary_sensor.bewegungsmelder_flur
```

---

## Troubleshooting

| Problem                    | Solution                                                              |
| -------------------------- | --------------------------------------------------------------------- |
| Integration not loading    | Check logs: `tail -f /config/home-assistant.log \| grep luxor_living` |
| LXP file not found         | Use absolute path (e.g., `/config/luxor/project.lxp`)                 |
| Gateway unreachable        | Verify IP address and port 3671, check firewall                       |
| Entities not created       | Check LXP file contains group addresses, restart HA                   |
| Tunneling connection fails | Try Routing mode or check BAOS authentication                         |

**Enable debug logging:**
```yaml
logger:
  default: info
  logs:
    custom_components.luxor_living: debug
```

---

## FAQ

**Q: Do I need ETS software?**  
A: No. Export LXP from Theben LUXORPlug software (included with gateway).

**Q: What's the difference between Tunneling and Routing?**  
A: Tunneling is recommended (authenticated, stable). Routing works without auth but may have firewall issues.

**Q: Can I test without hardware?**  
A: Yes. Enable "Simulation Mode" in integration options for dry-run testing.

**Q: Which group addresses are supported?**  
A: All DPT types in LXP file are parsed. Light (DPT 1.001, 5.001), Switch (DPT 1.001), Binary Sensors (DPT 1.x).

**Q: How long does initial state reading take?**  
A: ~30ms per entity via GroupValueRead. Example: 27 lights = ~800ms.

---

## Advanced Configuration

### Simulation Mode

Test without hardware by enabling in integration options:
**Settings** → **Devices & Services** → **LUXORliving** → **Options** → Enable **Simulation Mode**

### Multiple Gateways

Add multiple integrations for different gateways:
1. Add integration → Configure gateway 1
2. Add integration again → Configure gateway 2

Each gateway creates separate entities.

---

## Documentation

- [Installation Guide](docs/INSTALLATION.md) – Detailed setup instructions
- [KNX Implementation](docs/KNX_IMPLEMENTATION.md) – Technical protocol details
- [Sensor Platform](docs/SENSOR_PLATFORM.md) – Temperature, Humidity, Pressure sensors (v0.3.1+)
- [Quality Improvements](docs/QUALITY_IMPROVEMENTS.md) – v0.3.0 changes
- [Port Configuration](docs/PORT_CONFIGURATION_ANALYSIS.md) – Architecture decisions

**For developers:**
- [Contributing Guide](docs/QUICKSTART.md) – Development setup
- [Test Report](docs/TEST_REPORT.md) – 85/85 tests (improved coverage)
- [Architecture](docs/ARCHITECTURE_DECISION.md) – Design decisions

---

## License

This project is licensed under the [LICENSE](LICENSE).

---

## Credits

- [Theben AG](https://www.theben.de/) – LUXORliving system
- [xknx](https://github.com/XKNX/xknx) – KNX/IP communication library
- Home Assistant Community
